from django.shortcuts import get_object_or_404, render
from django.utils.translation import gettext as _
from django.utils import timezone
from django.http import HttpResponseRedirect
from django.utils.translation import activate, check_for_language
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.auth import views as auth_views
from django.urls import reverse_lazy
from members.models import Member
from mission_records.models import MissionRecord
from natural_disasters.models import DisasterEvent, DisasterEventPhoto
from datetime import datetime

def weekly_food_counter():
    # Sunday, Dec 14, 2025, 3:00 PM)
    start_date = datetime(2025, 12, 14, 18, 0, 0)
    now = datetime.now()
    
    if now < start_date:
        return 0
    
    diff = now - start_date
    weeks_passed = diff.days // 7
    
    return 172 + weeks_passed

def home(request):
    user = request.user
    member = getattr(user, 'member_profile', None)
    title = _("Saytaman Social Welfare Association")
    now = timezone.now().year
    missions = MissionRecord.objects.all().order_by('-date', '-time')
    missions_count = missions.count()
    weekly_food_count = weekly_food_counter()

    if not member:
        return render(request, 'index.html',
                      {
                          'title': title,
                          'now': now,
                          'missions_count': missions_count,
                          'weekly_food_count': weekly_food_count,
                       })
    else:
        return render(request, 'index.html',
                      {
                          'member_role': member.role,
                          'missions': missions,
                          'missions_count': missions_count,
                          'weekly_food_count': weekly_food_count,
                          'title': title,
                          'now': now,
                       })


def toggle_language(request):
    next_url = request.GET.get('next', request.META.get('HTTP_REFERER', '/'))
    current = request.COOKIES.get(settings.LANGUAGE_COOKIE_NAME, settings.LANGUAGE_CODE)
    next_lang = 'my' if current == 'en' else 'en'
    response = HttpResponseRedirect(next_url)
    if check_for_language(next_lang):
        response.set_cookie(settings.LANGUAGE_COOKIE_NAME, next_lang)
        activate(next_lang)
    return response

class MemberPasswordChangeView(auth_views.PasswordChangeView):
    """Subclass PasswordChangeView to clear the member.must_change_password flag after a successful change."""
    template_name = 'registration/password_change_form.html'
    success_url = reverse_lazy('password_change_done')

    def form_valid(self, form):
        response = super().form_valid(form)
        user = self.request.user
        member = getattr(user, 'member_profile', None)
        if member:
            member.must_change_password = False
            member.save(update_fields=['must_change_password'])
        return response

@login_required
def member_list(request):
    members = Member.objects.order_by('-member_id')[:]
    now = timezone.now().year
    
    return render(request, 'members/member_list.html',{'members': members, 'now': now})

def our_missions(request):
    now = timezone.now().year
    title = _("Our Mission")
    missions = MissionRecord.objects.all().order_by('-date', '-time')
    missions_count = missions.count()
    weekly_food_count = weekly_food_counter()

    context = {
        'now': now,
        'title': title,
        'missions_count': missions_count,
        'weekly_food_count': weekly_food_count,
        }
    return render(request, 'web_portal/our_missions.html', context)

def disaster_response(request):
    now = timezone.now().year
    title = _("Disaster Response")
    disaster_events = DisasterEvent.objects.all().order_by('-date')
    #event = get_object_or_404(DisasterEvent, pk=pk)
    #event_photos = event.disaster_photos.all()
    context = {
        'now': now,
        'title': title,
        'disaster_events': disaster_events,
        #'event': event,
        #'event_photos': event_photos
        }
    return render(request, 'web_portal/disaster_response.html', context)